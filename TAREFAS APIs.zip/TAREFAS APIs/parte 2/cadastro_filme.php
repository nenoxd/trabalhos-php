<?php
$servername = "127.0.0.1";
$username = "BRENO";
$password = '12345';
$dbname = "exemplo_TMDB_filmes";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $titulo = $_POST['titulo'];
    $ano = $_POST['ano'];
    $descricao = $_POST['descricao'];

    
    $api_key = 'sec228e84bccbe5dfbf911dfd774c36bb';
    
    $url = "https://api.themoviedb.org/3/search/movie?api_key={$api_key}&query={$titulo}&year={$ano}";
    $response = file_get_contents($url);
    $data = json_decode($response, true);

    if (isset($data['results'][0])) {
        $filme = $data['results'][0];
        $id_filme = $filme['id'];

        $stmt = $conn->prepare("INSERT INTO tbFilmes (titulo, ano, descricao, id_filme) 
                                VALUES (:titulo, :ano, :descricao, :id_filme)");

        $stmt->bindParam(':titulo', $titulo);
        $stmt->bindParam(':ano', $ano);
        $stmt->bindParam(':descricao', $descricao);
        $stmt->bindParam(':id_filme', $id_filme);

        $stmt->execute();

        echo "Cadastro de filme realizado com sucesso!";
    } else {
        throw new Exception("Filme não encontrado na API do TMDb.");
    }
} catch (Exception $e) {
    echo "Erro ao cadastrar filme: " . $e->getMessage();
} finally {
    $conn = null;
}
?>
