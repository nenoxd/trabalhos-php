<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Filme</title>
</head>
<body>
    <h2>Cadastro de Filme</h2>
    <form action="cadastro_filme.php" method="post">
        <label for="titulo">Título do Filme:</label>
        <input type="text" name="titulo" required><br>

        <label for="ano">Ano de Lançamento:</label>
        <input type="text" name="ano" required><br>

        <label for="descricao">Descrição:</label>
        <textarea name="descricao" rows="4" required></textarea><br>

        <button type="submit">Cadastrar</button>
    </form>

    <script>
        function buscarFilme() {
        }
    </script>
</body>
</html>
