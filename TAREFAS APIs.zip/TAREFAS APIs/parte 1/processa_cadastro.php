<?php
$servername = "127.0.0.1";
$username = "BRENO";
$password = '12345';
$dbname = "exemplo_via_cep";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $nome = $_POST['nome'];
    $cep = $_POST['cep'];

    $url = "https://viacep.com.br/ws/{$cep}/json/";
    $response = file_get_contents($url);
    $data = json_decode($response);

    $endereco = $data->logradouro ?? '';
    $bairro = $data->bairro ?? '';
    $cidade = $data->localidade ?? '';

    $stmt = $conn->prepare("INSERT INTO tbCliente (nomeCliente, cepCliente, enderecoCliente, bairroCliente, cidadeCliente) 
                            VALUES (:nome, :cep, :endereco, :bairro, :cidade)");

    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':cep', $cep);
    $stmt->bindParam(':endereco', $endereco);
    $stmt->bindParam(':bairro', $bairro);
    $stmt->bindParam(':cidade', $cidade);

    $stmt->execute();

    echo "Cadastro realizado com sucesso!";
} catch (PDOException $e) {
    echo "Erro ao cadastrar: " . $e->getMessage();
}

$conn = null;
?>
