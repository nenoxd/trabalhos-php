<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Cliente</title>
</head>
<body>
    <h2>Cadastro de Cliente</h2>
    <form action="processa_cadastro.php" method="post">
        <label for="nome">Nome:</label>
        <input type="text" name="nome" required><br>

        <label for="cep">CEP:</label>
        <input type="text" name="cep" id="cep" required>
        <button type="button" onclick="buscarCep()">Buscar CEP</button><br>

        <label for="endereco">Endereço:</label>
        <input type="text" name="endereco" id="endereco" readonly><br>

        <label for="bairro">Bairro:</label>
        <input type="text" name="bairro" id="bairro" readonly><br>

        <label for="cidade">Cidade:</label>
        <input type="text" name="cidade" id="cidade" readonly><br>

        <button type="submit">Cadastrar</button>
    </form>

    <script>
        function buscarCep() {
            var cep = document.getElementById('cep').value;

            fetch(`https://viacep.com.br/ws/${cep}/json/`)
                .then(response => response.json())
                .then(data => {
                    document.getElementById('endereco').value = data.logradouro;
                    document.getElementById('bairro').value = data.bairro;
                    document.getElementById('cidade').value = data.localidade;
                })
                .catch(error => {
                    console.error('Erro ao buscar CEP:', error);
                });
        }
    </script>
</body>
</html>
